function ChangeColor(gameObject)
    local renderer = gameObject:GetComponent(UnityEngine.Renderer)
end