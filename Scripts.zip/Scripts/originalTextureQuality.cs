using UnityEngine;

public class TextureQualityManager : MonoBehaviour
{
    private int originalTextureQuality;

    private void Start()
    {
        // Simpan pengaturan kualitas tekstur awal
        originalTextureQuality = QualitySettings.masterTextureLimit;
    }

    private void Update()
    {
        // Tekan tombol "+" untuk meningkatkan kualitas tekstur
        if (Input.GetKeyDown(KeyCode.Equals) || Input.GetKeyDown(KeyCode.KeypadPlus))
        {
            IncreaseTextureQuality();
        }
        // Tekan tombol "-" untuk menurunkan kualitas tekstur
        else if (Input.GetKeyDown(KeyCode.Minus) || Input.GetKeyDown(KeyCode.KeypadMinus))
        {
            DecreaseTextureQuality();
        }
    }

    private void IncreaseTextureQuality()
    {
        if (QualitySettings.masterTextureLimit > 0)
        {
            QualitySettings.masterTextureLimit--;
            Debug.Log("Increased Texture Quality: " + QualitySettings.masterTextureLimit);
        }
    }

    private void DecreaseTextureQuality()
    {
        if (QualitySettings.masterTextureLimit < 2) // Batas maksimal: 2 (sesuai dokumentasi Unity)
        {
            QualitySettings.masterTextureLimit++;
            Debug.Log("Decreased Texture Quality: " + QualitySettings.masterTextureLimit);
        }
    }
}