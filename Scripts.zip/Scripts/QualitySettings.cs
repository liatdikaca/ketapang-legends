using UnityEngine;

public class AutoFPSQualityController : MonoBehaviour
{
    public int targetFPS = 60;
    public float checkInterval = 2f; // Cek setiap 2 detik
    public int minQuality = 0;       // Level kualitas minimum (Fastest)
    public int maxQuality = 5;       // Level kualitas maksimum (Ultra)

    private float timer;
    private int frameCount;
    private float currentFPS;

    void Start()
    {
        Application.targetFrameRate = targetFPS;
    }

    void Update()
    {
        frameCount++;
        timer += Time.unscaledDeltaTime;

        if (timer >= checkInterval)
        {
            currentFPS = frameCount / timer;

            // Debug log
            Debug.Log("Current FPS: " + currentFPS);

            // Cek dan sesuaikan kualitas
            AdjustQualityBasedOnFPS();

            // Reset perhitungan
            timer = 0;
            frameCount = 0;
        }
    }

    void AdjustQualityBasedOnFPS()
    {
        int currentQuality = QualitySettings.GetQualityLevel();

        if (currentFPS < targetFPS - 10 && currentQuality > minQuality)
        {
            QualitySettings.DecreaseLevel();
            Debug.Log("📉 FPS rendah, turunkan kualitas ke " + QualitySettings.GetQualityLevel());
        }
        else if (currentFPS > targetFPS + 10 && currentQuality < maxQuality)
        {
            QualitySettings.IncreaseLevel();
            Debug.Log("📈 FPS tinggi, naikkan kualitas ke " + QualitySettings.GetQualityLevel());
        }
    }
}