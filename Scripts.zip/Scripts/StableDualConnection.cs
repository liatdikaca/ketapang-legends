using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections;

public class StableDualConnection : MonoBehaviour
{
    public string serverIP = "192.168.1.6";  // IP server kamu
    public int udpPort = 7777;
    public int tcpPort = 8888;

    private UdpClient udpClient;
    private IPEndPoint udpEndPoint;

    private TcpClient tcpClient;
    private NetworkStream tcpStream;

    private float heartbeatInterval = 3f;
    private float timeoutThreshold = 5f;
    private float lastUdpResponseTime;
    private float lastTcpResponseTime;

    private bool isUDPConnected = false;
    private bool isTCPConnected = false;

    void Start()
    {
        ConnectTCP();
        ConnectUDP();

        StartCoroutine(UDPHeartbeat());
        StartCoroutine(TCPHeartbeat());
        StartCoroutine(UDPReceiver());
        StartCoroutine(TCPReceiver());
    }

    // ---------------- UDP ----------------
    void ConnectUDP()
    {
        udpEndPoint = new IPEndPoint(IPAddress.Parse(serverIP), udpPort);
        udpClient = new UdpClient();
        udpClient.Connect(udpEndPoint);
        isUDPConnected = true;
        lastUdpResponseTime = Time.time;
    }

    IEnumerator UDPHeartbeat()
    {
        while (true)
        {
            if (isUDPConnected)
            {
                byte[] ping = Encoding.UTF8.GetBytes("udp_ping");
                udpClient.Send(ping, ping.Length);
            }
            yield return new WaitForSeconds(heartbeatInterval);
        }
    }

    IEnumerator UDPReceiver()
    {
        while (true)
        {
            if (udpClient.Available > 0)
            {
                byte[] data = udpClient.Receive(ref udpEndPoint);
                string msg = Encoding.UTF8.GetString(data);

                if (msg == "udp_pong")
                {
                    lastUdpResponseTime = Time.time;
                }
            }

            if (Time.time - lastUdpResponseTime > timeoutThreshold)
            {
                isUDPConnected = false;
                ReconnectUDP();
            }

            yield return null;
        }
    }

    void ReconnectUDP()
    {
        udpClient?.Close();
        ConnectUDP();
    }

    // ---------------- TCP ----------------
    void ConnectTCP()
    {
        try
        {
            tcpClient = new TcpClient(serverIP, tcpPort);
            tcpStream = tcpClient.GetStream();
            isTCPConnected = true;
            lastTcpResponseTime = Time.time;
        }
        catch
        {
            isTCPConnected = false;
        }
    }

    IEnumerator TCPHeartbeat()
    {
        while (true)
        {
            if (isTCPConnected && tcpStream != null && tcpStream.CanWrite)
            {
                byte[] ping = Encoding.UTF8.GetBytes("tcp_ping\n");
                tcpStream.Write(ping, 0, ping.Length);
            }
            yield return new WaitForSeconds(heartbeatInterval);
        }
    }

    IEnumerator TCPReceiver()
    {
        byte[] buffer = new byte[1024];

        while (true)
        {
            if (isTCPConnected && tcpStream.DataAvailable)
            {
                int bytesRead = tcpStream.Read(buffer, 0, buffer.Length);
                string msg = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();

                if (msg == "tcp_pong")
                {
                    lastTcpResponseTime = Time.time;
                }
            }

            if (Time.time - lastTcpResponseTime > timeoutThreshold)
            {
                isTCPConnected = false;
                ReconnectTCP();
            }

            yield return null;
        }
    }

    void ReconnectTCP()
    {
        tcpClient?.Close();
        ConnectTCP();
    }

    void OnApplicationQuit()
    {
        udpClient?.Close();
        tcpClient?.Close();
    }
}