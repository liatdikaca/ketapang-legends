using UnityEngine;
using System.Collections;

public class PerformanceAndNetworkManager : MonoBehaviour
{
    [Header("FPS Settings")]
    public int targetFPS = 60;
    public float checkInterval = 2f;
    public int minQuality = 0;
    public int maxQuality = 5;
    private float timer;
    private int frameCount;
    private float currentFPS;
    private float lastQualityChangeTime = 0f;
    public float qualityCooldown = 5f;

    [Header("Network Check")]
    public float networkCheckInterval = 5f;

    void Start()
    {
        Application.targetFrameRate = targetFPS;
        StartCoroutine(NetworkStabilityChecker());
        Resources.UnloadUnusedAssets(); // Bebaskan memori

        // Optional: Jika aplikasi utility, jangan running saat background
        Application.runInBackground = false;
    }

    void Update()
    {
        // FPS monitoring
        frameCount++;
        timer += Time.unscaledDeltaTime;

        if (timer >= checkInterval)
        {
            currentFPS = frameCount / timer;
            AdjustQuality();
            frameCount = 0;
            timer = 0;
        }
    }

    void AdjustQuality()
    {
        if (Time.time - lastQualityChangeTime < qualityCooldown)
            return;

        int currentQuality = QualitySettings.GetQualityLevel();

        if (currentFPS < targetFPS - 10 && currentQuality > minQuality)
        {
            QualitySettings.DecreaseLevel();
            lastQualityChangeTime = Time.time;
            Debug.Log("📉 FPS drop, turunkan kualitas ke " + QualitySettings.GetQualityLevel());
        }
        else if (currentFPS > targetFPS + 10 && currentQuality < maxQuality)
        {
            QualitySettings.IncreaseLevel();
            lastQualityChangeTime = Time.time;
            Debug.Log("📈 FPS tinggi, naikkan kualitas ke " + QualitySettings.GetQualityLevel());
        }
    }

    IEnumerator NetworkStabilityChecker()
    {
        while (true)
        {
            yield return new WaitForSeconds(networkCheckInterval);

            if (Application.internetReachability == NetworkReachability.NotReachable)
            {
                Debug.LogWarning("⚠️ Tidak ada koneksi internet!");
                // Bisa tampilkan UI reconnect atau notifikasi di layar
            }
            else
            {
                Debug.Log("✅ Koneksi internet stabil");
            }
        }
    }

    void OnApplicationPause(bool pause)
    {
        if (pause)
        {
            Debug.Log("⏸ Game dijeda");
        }
        else
        {
            Debug.Log("▶️ Game kembali aktif");
            Resources.UnloadUnusedAssets(); // Optimasi memori saat balik dari background
        }
    }

    void OnGUI()
    {
        GUIStyle style = new GUIStyle();
        style.fontSize = 24;
        style.normal.textColor = Color.green;
        GUI.Label(new Rect(10, 10, 300, 30), "FPS: " + Mathf.RoundToInt(currentFPS), style);
    }
}