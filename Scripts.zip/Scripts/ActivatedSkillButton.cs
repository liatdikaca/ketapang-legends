using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class SkillButtonWithDelay : MonoBehaviour
{
    public Button skillButton;
    public float delayTime = 0.1f;      // Delay sebelum skill aktif
    public float cooldownTime = 2f;     // Cooldown dasar

    private bool isCooldown = false;

    void Start()
    {
        skillButton.onClick.AddListener(DelayedUseSkill);
    }

    void DelayedUseSkill()
    {
        if (!isCooldown)
        {
            StartCoroutine(ActivateSkillWithDelay());
        }
    }

    IEnumerator ActivateSkillWithDelay()
    {
        yield return new WaitForSeconds(delayTime);

        UseSkill();

        isCooldown = true;
        skillButton.interactable = false;

        // Cooldown 20% lebih cepat (80% dari waktu asli)
        float adjustedCooldown = cooldownTime * 0.8f;
        yield return new WaitForSeconds(adjustedCooldown);

        isCooldown = false;
        skillButton.interactable = true;
    }

    void UseSkill()
    {
        Debug.Log("Skill used!");
    }
}