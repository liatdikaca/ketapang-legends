using UnityEngine;

public class GameSettings : MonoBehaviour
{
    private int graphicsQuality;
    private bool enableEffects;
    private int targetFPS;

    private void Start()
    {
        // Default: Prioritaskan performa
        graphicsQuality = PlayerPrefs.GetInt("GraphicsQuality", 0); // 0 = Fastest
        enableEffects = PlayerPrefs.GetInt("EnableEffects", 0) == 1; // Off by default
        targetFPS = PlayerPrefs.GetInt("TargetFPS", 60); // 60 FPS default

        ApplySettings();
    }

    private void ApplySettings()
    {
        // Set kualitas grafis
        QualitySettings.SetQualityLevel(graphicsQuality, true);

        // Batas FPS
        Application.targetFrameRate = targetFPS;

        // Matikan efek berat (misalnya post-processing, shadows, dll)
        ToggleVisualEffects(enableEffects);

        Debug.Log("Game Settings Applied: Quality " + graphicsQuality + ", FPS " + targetFPS + ", Effects " + enableEffects);
    }

    private void ToggleVisualEffects(bool enabled)
    {
        // Contoh: matikan efek yang berat
        var postFX = GameObject.Find("PostProcessing");
        if (postFX != null) postFX.SetActive(enabled);

        // Tambahkan efek lain seperti Particle, Bloom, Shadow, dll di sini jika perlu
    }

    public void SetGraphicsQuality(int quality)
    {
        graphicsQuality = quality;
        PlayerPrefs.SetInt("GraphicsQuality", graphicsQuality);
        ApplySettings();
    }

    public void ToggleEffects(bool enable)
    {
        enableEffects = enable;
        PlayerPrefs.SetInt("EnableEffects", enableEffects ? 1 : 0);
        ApplySettings();
    }

    public void SetTargetFPS(int fps)
    {
        targetFPS = fps;
        PlayerPrefs.SetInt("TargetFPS", targetFPS);
        ApplySettings();
    }
}