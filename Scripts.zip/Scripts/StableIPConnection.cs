using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections;

public class StableDualConnection : MonoBehaviour
{
    public enum IPMode
    {
        Local,
        VPN,
        DNS
    }

    [Header("Server Configuration")]
    public IPMode currentMode = IPMode.Local;
    public int udpPort = 7777;
    public int tcpPort = 8888;

    private UdpClient udpClient;
    private IPEndPoint udpEndPoint;

    private TcpClient tcpClient;
    private NetworkStream tcpStream;

    private float heartbeatInterval = 3f;
    private float timeoutThreshold = 5f;
    private float lastUdpResponseTime;
    private float lastTcpResponseTime;

    private bool isUDPConnected = false;
    private bool isTCPConnected = false;

    void Start()
    {
        // Deteksi IP mode otomatis
        currentMode = DetectIPMode();

        ConnectTCP();
        ConnectUDP();

        StartCoroutine(UDPHeartbeat());
        StartCoroutine(TCPHeartbeat());
        StartCoroutine(UDPReceiver());
        StartCoroutine(TCPReceiver());
    }

    // ---------------- IP Logic ----------------
    private string GetServerIP()
    {
        switch (currentMode)
        {
            case IPMode.Local: return "192.168.1.7";
            case IPMode.VPN: return "10.9.0.47";
            case IPMode.DNS: return "94.140.15.15";
            default: return "127.0.0.1";
        }
    }

    private IPMode DetectIPMode()
    {
        string localIP = GetLocalIPAddress();

        if (localIP.StartsWith("10.")) return IPMode.VPN;
        if (localIP.StartsWith("192.168.")) return IPMode.Local;

        return IPMode.DNS;
    }

    private string GetLocalIPAddress()
    {
        foreach (var ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
        {
            if (ip.AddressFamily == AddressFamily.InterNetwork)
                return ip.ToString();
        }
        return "127.0.0.1";
    }

    // ---------------- UDP ----------------
    void ConnectUDP()
    {
        string serverIP = GetServerIP();
        udpEndPoint = new IPEndPoint(IPAddress.Parse(serverIP), udpPort);
        udpClient = new UdpClient();
        udpClient.Connect(udpEndPoint);
        isUDPConnected = true;
        lastUdpResponseTime = Time.time;
        Debug.Log("🟢 UDP Connected to " + serverIP + ":" + udpPort);
    }

    IEnumerator UDPHeartbeat()
    {
        while (true)
        {
            if (isUDPConnected)
            {
                byte[] ping = Encoding.UTF8.GetBytes("udp_ping");
                udpClient.Send(ping, ping.Length);
            }
            yield return new WaitForSeconds(heartbeatInterval);
        }
    }

    IEnumerator UDPReceiver()
    {
        while (true)
        {
            if (udpClient.Available > 0)
            {
                byte[] data = udpClient.Receive(ref udpEndPoint);
                string msg = Encoding.UTF8.GetString(data);

                if (msg == "udp_pong")
                {
                    lastUdpResponseTime = Time.time;
                    Debug.Log("📶 UDP Pong received");
                }
            }

            if (Time.time - lastUdpResponseTime > timeoutThreshold)
            {
                isUDPConnected = false;
                Debug.LogWarning("❌ UDP timeout, reconnecting...");
                ReconnectUDP();
            }

            yield return null;
        }
    }

    void ReconnectUDP()
    {
        udpClient?.Close();
        ConnectUDP();
    }

    // ---------------- TCP ----------------
    void ConnectTCP()
    {
        try
        {
            string serverIP = GetServerIP();
            tcpClient = new TcpClient(serverIP, tcpPort);
            tcpStream = tcpClient.GetStream();
            isTCPConnected = true;
            lastTcpResponseTime = Time.time;
            Debug.Log("🟢 TCP Connected to " + serverIP + ":" + tcpPort);
        }
        catch
        {
            isTCPConnected = false;
            Debug.LogError("❌ TCP Connection failed");
        }
    }

    IEnumerator TCPHeartbeat()
    {
        while (true)
        {
            if (isTCPConnected && tcpStream != null && tcpStream.CanWrite)
            {
                byte[] ping = Encoding.UTF8.GetBytes("tcp_ping\n");
                tcpStream.Write(ping, 0, ping.Length);
            }
            yield return new WaitForSeconds(heartbeatInterval);
        }
    }

    IEnumerator TCPReceiver()
    {
        byte[] buffer = new byte[1024];

        while (true)
        {
            if (isTCPConnected && tcpStream.DataAvailable)
            {
                int bytesRead = tcpStream.Read(buffer, 0, buffer.Length);
                string msg = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();

                if (msg == "tcp_pong")
                {
                    lastTcpResponseTime = Time.time;
                    Debug.Log("📶 TCP Pong received");
                }
            }

            if (Time.time - lastTcpResponseTime > timeoutThreshold)
            {
                isTCPConnected = false;
                Debug.LogWarning("❌ TCP timeout, reconnecting...");
                ReconnectTCP();
            }

            yield return null;
        }
    }

    void ReconnectTCP()
    {
        tcpClient?.Close();
        ConnectTCP();
    }

    void OnApplicationQuit()
    {
        udpClient?.Close();
        tcpClient?.Close();
    }
}